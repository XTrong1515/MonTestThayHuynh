// Global using directives – áp dụng cho toàn bộ project
// Giúp mỗi file không cần lặp lại các using phổ biến

global using SeleniumFramework.Framework.Config;
global using SeleniumFramework.Framework.Utils;
