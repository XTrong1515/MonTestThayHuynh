# LAB 9 — PAGE OBJECT MODEL NÂNG CAO + DATA-DRIVEN TESTING
## Ngôn ngữ: C# | Framework: NUnit + Selenium 4.x

---

## 📁 Cấu trúc thư mục

```
SeleniumFramework/
├── SeleniumFramework.csproj          ← NuGet packages
├── GlobalUsings.cs                   ← Global imports
├── Framework/
│   ├── Base/
│   │   ├── BasePage.cs               ← BÀI 1: 7 method, Explicit Wait
│   │   ├── BaseTest.cs               ← BÀI 1: ThreadLocal<IWebDriver>, screenshot
│   │   └── DriverFactory.cs          ← Tạo driver theo browser
│   ├── Config/
│   │   └── ConfigReader.cs           ← BÀI 5: Singleton, đa môi trường
│   ├── Pages/
│   │   ├── LoginPage.cs              ← BÀI 2: Fluent Interface POM
│   │   ├── InventoryPage.cs          ← BÀI 2: AddItem, GoToCart
│   │   └── CartPage.cs               ← BÀI 2: CartPage + CheckoutPage
│   └── Utils/
│       ├── ExcelReader.cs            ← BÀI 3: EPPlus, 4 kiểu cell
│       ├── JsonReader.cs             ← BÀI 4A: Newtonsoft.Json, UserData
│       ├── TestDataFactory.cs        ← BÀI 4B: Bogus (Java Faker)
│       ├── RetryAnalyzer.cs          ← BÀI 6: NUnit IRepeatTest
│       └── ScreenshotUtil.cs         ← Chụp ảnh khi fail
├── Tests/
│   ├── LoginTest.cs                  ← BÀI 2: 7 test methods
│   ├── CartTest.cs                   ← BÀI 2: 6 test methods
│   ├── LoginDDTTest.cs               ← BÀI 3: DDT từ Excel (3 sheets)
│   ├── UserLoginTest.cs              ← BÀI 4: JSON + Faker
│   ├── ConfigReaderTest.cs           ← BÀI 5: Multi-env verification
│   ├── FlakySimulationTest.cs        ← BÀI 6: Retry mô phỏng
│   └── CheckoutTest.cs               ← BÀI 7: Tổng hợp Refactor
└── Resources/
    ├── config/
    │   ├── config-dev.properties     ← URL saucedemo, wait=15, retry=1
    │   └── config-staging.properties ← URL staging, wait=20, retry=2
    └── testdata/
        ├── login_data.xlsx           ← 3 sheets: Smoke/Negative/Boundary
        └── users.json                ← 5 users: success + failure cases
```

---

## ⚙️ Cài đặt & Chạy

### 1. Cài .NET 8 SDK
```bash
# Kiểm tra version
dotnet --version
```

### 2. Restore packages
```bash
cd SeleniumFramework
dotnet restore
```

### 3. Chạy tất cả test (môi trường dev mặc định)
```bash
dotnet test
```

### 4. Chạy theo môi trường
```bash
# Dev (mặc định)
dotnet test

# Staging – explicit.wait=20, retry.count=2
ENV=staging dotnet test

# Windows PowerShell
$env:ENV="staging"; dotnet test
```

### 5. Chạy theo Category (group)
```bash
# Chỉ smoke tests (SmokeCases sheet)
dotnet test --filter "Category=smoke"

# Negative tests
dotnet test --filter "Category=negative"

# Toàn bộ regression (3 sheets)
dotnet test --filter "Category=regression"

# DDT từ Excel
dotnet test --filter "Category=ddt"

# DDT từ JSON
dotnet test --filter "Category=json-ddt"

# Faker data
dotnet test --filter "Category=faker"

# Retry simulation
dotnet test --filter "Category=retry"

# Config tests (không cần browser)
dotnet test --filter "Category=config"
```

---

## 📋 Bài tập & điểm số

| Bài | Nội dung | Files chính | Điểm |
|-----|----------|-------------|------|
| 1 | BasePage + BaseTest | `BasePage.cs`, `BaseTest.cs` | 1.0 |
| 2 | Page Objects SauceDemo | `LoginPage.cs`, `InventoryPage.cs`, `CartPage.cs` | 1.0 |
| 3 | DDT từ Excel 3 sheets | `ExcelReader.cs`, `LoginDDTTest.cs`, `login_data.xlsx` | 1.0 |
| 4 | JSON + Java Faker | `JsonReader.cs`, `TestDataFactory.cs`, `UserLoginTest.cs` | 1.0 |
| 5 | ConfigReader đa môi trường | `ConfigReader.cs`, `ConfigReaderTest.cs`, `*.properties` | 1.0 |
| 6 | RetryAnalyzer | `RetryAnalyzer.cs`, `FlakySimulationTest.cs` | 1.0 |
| 7 | Refactor tổng hợp | `CheckoutTest.cs` + toàn bộ framework | 1.0 |

---

## 🔑 Nguyên tắc bắt buộc (vi phạm → trừ điểm)

1. ✅ Mọi `@Test` dùng `GetDriver()` từ `BaseTest` – **KHÔNG** `new ChromeDriver()`
2. ✅ Mọi `FindElement()` nằm trong **Page Object** – **KHÔNG** trong test class
3. ✅ URL, username, password đọc từ file config/Excel/JSON – **KHÔNG** hardcode
4. ✅ **KHÔNG** dùng `Thread.Sleep()` ở bất kỳ đâu
5. ✅ Nộp kèm file `login_data.xlsx` cùng source code

---

## 📌 Nhận xét: POM vs Naive Test

1. **Bảo trì dễ hơn**: Locator định nghĩa 1 lần trong Page Object → UI đổi chỉ sửa 1 chỗ
2. **Tái sử dụng**: `LoginPage.Login()` dùng được trong mọi test – không copy-paste code
3. **Đọc được như nghiệp vụ**: `loginPage.Login(u,p).addToCart().goToCart()` rõ ràng hơn raw Selenium
4. **DDT tách biệt**: QA thêm test case vào Excel/JSON mà không cần biết Java/C#
5. **Chạy song song an toàn**: `ThreadLocal<IWebDriver>` trong BaseTest tránh conflict
