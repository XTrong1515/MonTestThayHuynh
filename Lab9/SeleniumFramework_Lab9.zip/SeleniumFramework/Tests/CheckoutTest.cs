using NUnit.Framework;
using SeleniumFramework.Framework.Base;
using SeleniumFramework.Framework.Pages;
using SeleniumFramework.Framework.Utils;

namespace SeleniumFramework.Tests
{
    /// <summary>
    /// BÀI 7: Dự án tổng hợp – Refactor toàn bộ test sang POM + DDT framework.
    ///
    /// Checklist refactor (so với Naive Test):
    ///   ✅ Tất cả locator nằm trong Page Object (LoginPage, InventoryPage, CartPage)
    ///   ✅ KHÔNG có Thread.Sleep() – thay bằng Explicit Wait trong BasePage
    ///   ✅ KHÔNG có new ChromeDriver() – thay bằng BaseTest.GetDriver()
    ///   ✅ Dữ liệu test đọc từ TestDataFactory (Faker) và @DataProvider (TestCaseSource)
    ///   ✅ Fluent Interface: login().addItem().goToCart().checkout()
    ///   ✅ Screenshot tự động khi test fail (BaseTest.TearDown)
    /// </summary>
    [TestFixture]
    [Category("regression")]
    public class CheckoutTest : BaseTest
    {
        // ─────────────────────────────────────────────────────────────
        // HELPER – đăng nhập và lấy InventoryPage
        // ─────────────────────────────────────────────────────────────
        private InventoryPage LoginAndGoToInventory(
            string username = "standard_user",
            string password = "secret_sauce")
        {
            return new LoginPage(GetDriver()).Login(username, password);
        }

        // ─────────────────────────────────────────────────────────────
        // BÀI 7 – CHECKOUT FLOW ĐẦY ĐỦ (Refactored)
        // ─────────────────────────────────────────────────────────────

        [Test]
        [Category("smoke")]
        [Description("BÀI 7: Checkout hoàn chỉnh với dữ liệu cố định")]
        [RetryOnFailure]
        public void TestCheckout_FullFlow_StaticData()
        {
            Console.WriteLine("[CheckoutTest] BÀI 7: Full checkout flow – static data");

            // Fluent Interface – toàn bộ chuỗi hành động trong 1 câu
            var checkoutPage = LoginAndGoToInventory()
                .AddFirstItemToCart()
                .GoToCart()
                .GoToCheckout();

            checkoutPage.FillShippingInfo("Nguyen", "Van A", "70000");
            checkoutPage.FinishOrder();

            Assert.That(checkoutPage.IsOrderComplete(), Is.True,
                "Trang hoàn thành đặt hàng không hiển thị");
            Assert.That(checkoutPage.GetCompleteHeaderText(),
                Does.Contain("THANK").Or.Contain("Thank"),
                "Header hoàn thành không đúng nội dung");
        }

        [Test]
        [Category("smoke")]
        [Description("BÀI 7: Checkout với dữ liệu ngẫu nhiên từ Bogus Faker")]
        [RetryOnFailure]
        public void TestCheckout_FullFlow_FakerData()
        {
            // Bogus sinh dữ liệu mỗi lần khác nhau – chứng minh DDT linh hoạt
            var data = TestDataFactory.RandomCheckoutData();
            Console.WriteLine($"[CheckoutTest] Faker data: {data["firstName"]} {data["lastName"]} | ZIP: {data["postalCode"]}");

            var checkoutPage = LoginAndGoToInventory()
                .AddFirstItemToCart()
                .GoToCart()
                .GoToCheckout();

            checkoutPage.FillShippingInfo(
                data["firstName"], data["lastName"], data["postalCode"]);
            checkoutPage.FinishOrder();

            Assert.That(checkoutPage.IsOrderComplete(), Is.True,
                $"Checkout thất bại với faker data: {data["firstName"]} {data["lastName"]}");
        }

        [Test]
        [Category("regression")]
        [Description("BÀI 7: Thêm nhiều item rồi checkout")]
        public void TestCheckout_MultipleItems()
        {
            var data = TestDataFactory.RandomCheckoutData();

            var inventoryPage = LoginAndGoToInventory();
            inventoryPage.AddItemByName("Sauce Labs Backpack");
            inventoryPage.AddItemByName("Sauce Labs Bike Light");

            Assert.That(inventoryPage.GetCartItemCount(), Is.EqualTo(2),
                "Giỏ phải có 2 item trước khi checkout");

            var checkoutPage = inventoryPage
                .GoToCart()
                .GoToCheckout();

            checkoutPage.FillShippingInfo(
                data["firstName"], data["lastName"], data["postalCode"]);
            checkoutPage.FinishOrder();

            Assert.That(checkoutPage.IsOrderComplete(), Is.True,
                "Checkout với 2 items phải thành công");
        }

        [Test]
        [Category("negative")]
        [Description("BÀI 7: Checkout thiếu thông tin – kiểm tra validation")]
        public void TestCheckout_MissingFirstName()
        {
            var checkoutPage = LoginAndGoToInventory()
                .AddFirstItemToCart()
                .GoToCart()
                .GoToCheckout();

            // Bỏ trống firstName để trigger validation
            checkoutPage.FillShippingInfo("", "Doe", "12345");

            var error = checkoutPage.GetErrorMessage();
            Assert.That(error, Does.Contain("First Name").Or.Contain("required"),
                "Phải có thông báo lỗi khi bỏ trống First Name");
        }

        [Test]
        [Category("regression")]
        [Description("BÀI 7: Giỏ hàng vẫn lưu item sau khi navigate")]
        public void TestCart_PersistsAfterNavigation()
        {
            var inventoryPage = LoginAndGoToInventory();
            inventoryPage.AddFirstItemToCart();

            int countBefore = inventoryPage.GetCartItemCount();

            // Navigate đi rồi quay lại cart
            var cartPage = inventoryPage.GoToCart();
            int countInCart = cartPage.GetItemCount();

            Assert.That(countInCart, Is.EqualTo(countBefore),
                "Số item trong cart phải bằng số item đã add");
        }

        [Test]
        [Category("regression")]
        [Description("BÀI 7: Xóa item khỏi cart rồi tiếp tục mua sắm")]
        public void TestCart_RemoveAndContinueShopping()
        {
            var cartPage = LoginAndGoToInventory()
                .AddFirstItemToCart()
                .GoToCart();

            Assert.That(cartPage.GetItemCount(), Is.EqualTo(1), "Phải có 1 item trước khi xóa");

            cartPage.RemoveFirstItem();
            Assert.That(cartPage.IsEmpty(), Is.True, "Giỏ phải rỗng sau khi xóa");

            var inventoryPage = cartPage.ContinueShopping();
            Assert.That(inventoryPage.IsLoaded(), Is.True,
                "Phải quay về trang inventory sau ContinueShopping");
        }

        // ─────────────────────────────────────────────────────────────
        // BÀI 7 – CHỨNG MINH FRAMEWORK (So sánh với Naive Test)
        // ─────────────────────────────────────────────────────────────

        [Test]
        [Category("smoke")]
        [Description("BÀI 7: Chứng minh không dùng FindElement trực tiếp trong test class")]
        public void TestPomCompliance_NoDirectFindElement()
        {
            // Test này chứng minh toàn bộ thao tác qua Page Object
            // KHÔNG có driver.FindElement() hay By.id() ở đây
            var loginPage = new LoginPage(GetDriver());

            // Kiểm tra Page Object hoạt động
            Assert.That(loginPage.IsLoaded(), Is.True,
                "LoginPage.IsLoaded() phải trả về true khi trang login hiển thị");

            Console.WriteLine("[POM-Compliance] ✅ Tất cả thao tác đi qua Page Object");
            Console.WriteLine("[POM-Compliance] ✅ Không có driver.FindElement() trong test class");
            Console.WriteLine("[POM-Compliance] ✅ Không có Thread.Sleep() trong toàn bộ framework");
        }
    }
}
