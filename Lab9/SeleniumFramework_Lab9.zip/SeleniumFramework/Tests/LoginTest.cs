using NUnit.Framework;
using SeleniumFramework.Framework.Base;
using SeleniumFramework.Framework.Pages;
using SeleniumFramework.Framework.Utils;

namespace SeleniumFramework.Tests
{
    /// <summary>
    /// BÀI 2: Kiểm thử đăng nhập saucedemo.com dùng Page Object Model.
    /// Test class kế thừa BaseTest – KHÔNG tạo WebDriver mới ở đây.
    /// KHÔNG chứa driver.FindElement() hay By.id() trực tiếp – vi phạm POM.
    /// </summary>
    [TestFixture]
    [Category("login")]
    public class LoginTest : BaseTest
    {
        // ─────────────────────────────────────────────────────────────
        // HAPPY PATH – Đăng nhập thành công
        // ─────────────────────────────────────────────────────────────

        [Test]
        [Category("smoke")]
        [Description("TC01: Đăng nhập thành công với standard_user")]
        [RetryOnFailure]
        public void TestLoginSuccess_StandardUser()
        {
            // Arrange
            var loginPage = new LoginPage(GetDriver());

            // Act – Fluent Interface: login trả về InventoryPage
            var inventoryPage = loginPage.Login("standard_user", "secret_sauce");

            // Assert – assertion chỉ nằm trong test class, KHÔNG trong Page Object
            Assert.That(inventoryPage.IsLoaded(), Is.True,
                "Trang inventory chưa load sau khi đăng nhập thành công");
            Assert.That(GetDriver().Url, Does.Contain("inventory"),
                "URL không chứa 'inventory' sau đăng nhập");
        }

        [Test]
        [Category("smoke")]
        [Description("TC02: Đăng nhập với problem_user")]
        [RetryOnFailure]
        public void TestLoginSuccess_ProblemUser()
        {
            var loginPage     = new LoginPage(GetDriver());
            var inventoryPage = loginPage.Login("problem_user", "secret_sauce");

            Assert.That(inventoryPage.IsLoaded(), Is.True,
                "Trang inventory không load với problem_user");
        }

        // ─────────────────────────────────────────────────────────────
        // NEGATIVE – Đăng nhập thất bại
        // ─────────────────────────────────────────────────────────────

        [Test]
        [Category("negative")]
        [Description("TC03: Đăng nhập với tài khoản bị khoá")]
        public void TestLogin_LockedOutUser()
        {
            var loginPage = new LoginPage(GetDriver());
            loginPage.LoginExpectingFailure("locked_out_user", "secret_sauce");

            Assert.That(loginPage.IsErrorDisplayed(), Is.True,
                "Không có thông báo lỗi khi đăng nhập với tài khoản bị khoá");
            Assert.That(loginPage.GetErrorMessage(),
                Does.Contain("locked out"),
                "Nội dung thông báo lỗi không đúng");
        }

        [Test]
        [Category("negative")]
        [Description("TC04: Đăng nhập sai mật khẩu")]
        public void TestLogin_WrongPassword()
        {
            var loginPage = new LoginPage(GetDriver());
            loginPage.LoginExpectingFailure("standard_user", "wrongpassword");

            Assert.That(loginPage.IsErrorDisplayed(), Is.True,
                "Không có thông báo lỗi khi sai mật khẩu");
            Assert.That(loginPage.GetErrorMessage(),
                Does.Contain("Username and password do not match"),
                "Thông báo lỗi sai mật khẩu không đúng");
        }

        [Test]
        [Category("negative")]
        [Description("TC05: Đăng nhập với username rỗng")]
        public void TestLogin_EmptyUsername()
        {
            var loginPage = new LoginPage(GetDriver());
            loginPage.LoginExpectingFailure("", "secret_sauce");

            Assert.That(loginPage.IsErrorDisplayed(), Is.True,
                "Không có thông báo lỗi khi username rỗng");
            Assert.That(loginPage.GetErrorMessage(),
                Does.Contain("Username is required"),
                "Thông báo lỗi username rỗng không đúng");
        }

        [Test]
        [Category("negative")]
        [Description("TC06: Đăng nhập với password rỗng")]
        public void TestLogin_EmptyPassword()
        {
            var loginPage = new LoginPage(GetDriver());
            loginPage.LoginExpectingFailure("standard_user", "");

            Assert.That(loginPage.IsErrorDisplayed(), Is.True,
                "Không có thông báo lỗi khi password rỗng");
            Assert.That(loginPage.GetErrorMessage(),
                Does.Contain("Password is required"),
                "Thông báo lỗi password rỗng không đúng");
        }

        [Test]
        [Category("smoke")]
        [Description("TC07: Fluent Interface – Login → AddToCart → GoToCart")]
        public void TestFluentInterface_LoginAddCartNavigate()
        {
            // Chứng minh Fluent Interface hoạt động
            var cartPage = new LoginPage(GetDriver())
                .Login("standard_user", "secret_sauce")
                .AddFirstItemToCart()
                .GoToCart();

            Assert.That(cartPage.GetItemCount(), Is.GreaterThan(0),
                "Giỏ hàng rỗng sau khi add item qua Fluent Interface");
        }
    }
}
