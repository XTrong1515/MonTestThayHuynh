using NUnit.Framework;
using SeleniumFramework.Framework.Base;
using SeleniumFramework.Framework.Utils;

namespace SeleniumFramework.Tests
{
    /// <summary>
    /// BÀI 6: RetryAnalyzer – Mô phỏng flaky test và kiểm chứng retry hoạt động đúng.
    ///
    /// Kịch bản 1 (retry.count=2): test fail lần 1, fail lần 2, PASS lần 3
    ///   → TestNG/NUnit Report: 2 RETRY → 1 PASS cuối cùng
    ///
    /// Kịch bản 2 (retry.count=0): test fail ngay lần đầu, không retry
    ///   → Thay đổi config-dev.properties: retry.count=0 rồi chạy lại
    /// </summary>
    [TestFixture]
    [Category("retry")]
    public class FlakySimulationTest : BaseTest
    {
        // Thread-safe counter – đếm số lần test được gọi
        private static int _callCount = 0;

        [SetUp]
        public new void SetUp()
        {
            // Gọi base setup (khởi tạo driver)
            base.SetUp();
        }

        // ─────────────────────────────────────────────────────────────
        // BÀI 6 – FLAKY TEST MÔ PHỎNG
        // ─────────────────────────────────────────────────────────────

        [Test]
        [RetryOnFailure(2)]
        [Description("BÀI 6: Test mô phỏng flaky – fail 2 lần đầu, pass lần thứ 3")]
        public void TestFlakyScenario_FailTwiceThenPass()
        {
            // Thread-safe increment
            var currentCall = Interlocked.Increment(ref _callCount);

            Console.WriteLine("┌─────────────────────────────────────────────┐");
            Console.WriteLine($"│ [FlakyTest] Đang chạy lần thứ: {currentCall,-14} │");
            Console.WriteLine("└─────────────────────────────────────────────┘");

            if (currentCall <= 2)
            {
                Console.WriteLine($"[FlakyTest] ❌ Mô phỏng lỗi mạng tạm thời – lần {currentCall}");
                Assert.Fail($"Mô phỏng lỗi mạng tạm thời – lần {currentCall}. " +
                            "RetryAnalyzer sẽ chạy lại tự động.");
            }

            Console.WriteLine($"[FlakyTest] ✅ Test PASS ở lần thứ {currentCall}");
            Assert.That(true, Is.True,
                $"Test pass ở lần thứ {currentCall} sau {currentCall - 1} lần retry");
        }

        [Test]
        [RetryOnFailure(0)]
        [Description("BÀI 6: Test với retry.count=0 – fail ngay, không retry")]
        [Ignore("Bỏ qua khi chạy toàn bộ suite – chỉ chạy khi demo retry.count=0")]
        public void TestNoRetry_FailImmediately()
        {
            Console.WriteLine("[FlakyTest] RetryCount=0 → fail ngay, không retry");
            Assert.Fail("Test này luôn fail – chứng minh retry.count=0 không retry");
        }

        // ─────────────────────────────────────────────────────────────
        // BÀI 6 – KIỂM TRA RETRY TRONG ĐIỀU KIỆN THỰC (với browser)
        // ─────────────────────────────────────────────────────────────

        /// <summary>
        /// Mô phỏng flaky test thực tế: đôi khi element load chậm.
        /// 50% chance fail → retry bù đắp instability.
        /// </summary>
        [Test]
        [RetryOnFailure(2)]
        [Description("BÀI 6: Flaky test thực tế – load trang và kiểm tra element")]
        public void TestFlakyBrowserScenario()
        {
            // Mô phỏng: lần đầu tiên call luôn fail
            var key = $"flaky_browser_{TestContext.CurrentContext.Test.ID}";

            if (!TestContext.Parameters.Exists(key))
            {
                // Lần chạy đầu tiên: đánh dấu và fail
                Console.WriteLine("[FlakyTest] Lần đầu – giả lập load chậm → fail");

                // Vẫn navigate để screenshot có ý nghĩa
                // driver đã được khởi tạo bởi BaseTest.SetUp()
                Assert.Fail("Giả lập: element không tìm thấy do load chậm lần đầu");
            }

            Console.WriteLine("[FlakyTest] Lần retry – trang đã load đầy đủ → pass");
            Assert.That(GetDriver().Url, Is.Not.Empty,
                "URL trang hiện tại không được rỗng");
        }

        // ─────────────────────────────────────────────────────────────
        // BÀI 6 – ĐỌC RETRY CONFIG
        // ─────────────────────────────────────────────────────────────

        [Test]
        [Category("config")]
        [Description("BÀI 6: Kiểm tra RetryAnalyzer đọc đúng retry.count từ config")]
        public void TestRetryConfig_ReadsFromConfigFile()
        {
            var retryCount = Framework.Config.ConfigReader.GetInstance().GetRetryCount();

            Console.WriteLine($"[RetryConfig] retry.count từ config = {retryCount}");
            Console.WriteLine($"[RetryConfig] Môi trường hiện tại = " +
                $"{Framework.Config.ConfigReader.GetInstance().GetCurrentEnv()}");

            // dev: retry.count=1, staging: retry.count=2
            Assert.That(retryCount, Is.GreaterThanOrEqualTo(0),
                "retry.count phải >= 0");
            Assert.That(retryCount, Is.LessThanOrEqualTo(5),
                "retry.count quá lớn – không nên retry quá 5 lần");

            Console.WriteLine($"[RetryConfig] ✅ retry.count={retryCount} hợp lệ");
        }
    }
}
