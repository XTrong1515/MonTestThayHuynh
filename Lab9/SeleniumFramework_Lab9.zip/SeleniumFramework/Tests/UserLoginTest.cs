using NUnit.Framework;
using SeleniumFramework.Framework.Base;
using SeleniumFramework.Framework.Pages;
using SeleniumFramework.Framework.Utils;

namespace SeleniumFramework.Tests
{
    /// <summary>
    /// BÀI 4A: Data-Driven Testing từ file users.json (5 test cases).
    /// BÀI 4B: Dùng Bogus (Java Faker) sinh dữ liệu checkout ngẫu nhiên.
    ///
    /// Mỗi lần chạy TestCheckout_WithFakerData → log ra dữ liệu khác nhau.
    /// Chạy 2 lần và so sánh log để chứng minh tính ngẫu nhiên.
    /// </summary>
    [TestFixture]
    [Category("json-ddt")]
    public class UserLoginTest : BaseTest
    {
        private static string JsonPath =>
            FindFile(Path.Combine("Resources", "testdata", "users.json"));

        private static string FindFile(string rel)
        {
            var candidates = new[]
            {
                rel,
                Path.Combine("..", rel),
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, rel),
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "..", "..", "..", rel),
            };
            return candidates.FirstOrDefault(File.Exists)
                   ?? throw new FileNotFoundException($"Không tìm thấy: {rel}");
        }

        // ─────────────────────────────────────────────────────────────
        // BÀI 4A – DATA SOURCE TỪ JSON
        // ─────────────────────────────────────────────────────────────

        /// <summary>
        /// Đọc 5 user từ users.json và trả về TestCaseData với tên từ cột description.
        /// Tên test hiển thị trong report = description trong JSON, không phải UserData[0].
        /// </summary>
        public static IEnumerable<TestCaseData> UserData()
            => JsonReader.GetUserTestCases(JsonPath);

        // ─────────────────────────────────────────────────────────────
        // BÀI 4A – 5 TEST CASES TỪ JSON
        // ─────────────────────────────────────────────────────────────

        [Test]
        [Category("json")]
        [TestCaseSource(nameof(UserData))]
        public void TestLogin_FromJson(string username, string password, bool expectSuccess)
        {
            Console.WriteLine($"[JSON-DDT] username='{username}' | expectSuccess={expectSuccess}");

            if (expectSuccess)
            {
                // Kỳ vọng đăng nhập thành công → trang inventory load
                var inventoryPage = new LoginPage(GetDriver()).Login(username, password);
                Assert.That(inventoryPage.IsLoaded(), Is.True,
                    $"[{username}] Trang inventory không load dù expectSuccess=true");
                Assert.That(GetDriver().Url, Does.Contain("inventory"),
                    $"[{username}] URL không đúng sau đăng nhập thành công");
            }
            else
            {
                // Kỳ vọng đăng nhập thất bại → có thông báo lỗi
                var loginPage = new LoginPage(GetDriver())
                    .LoginExpectingFailure(username, password);

                Assert.That(loginPage.IsErrorDisplayed(), Is.True,
                    $"[{username}] Không có thông báo lỗi dù expectSuccess=false");
            }
        }

        // ─────────────────────────────────────────────────────────────
        // BÀI 4B – JAVA FAKER (Bogus) – SINH DỮ LIỆU NGẪU NHIÊN
        // ─────────────────────────────────────────────────────────────

        [Test]
        [Category("faker")]
        [Description("BÀI 4B: Checkout với dữ liệu ngẫu nhiên từ Bogus (Faker)")]
        [RetryOnFailure]
        public void TestCheckout_WithFakerData_Run1()
        {
            // Sinh dữ liệu ngẫu nhiên – mỗi lần gọi cho kết quả khác nhau
            var data = TestDataFactory.RandomCheckoutData();

            Console.WriteLine("╔══════════════════════════════════════════╗");
            Console.WriteLine("║  BÀI 4B – RUN 1: Faker Data              ║");
            Console.WriteLine($"║  Tên: {data["firstName"]} {data["lastName"],-20} ║");
            Console.WriteLine($"║  ZIP: {data["postalCode"],-35} ║");
            Console.WriteLine("╚══════════════════════════════════════════╝");

            var checkoutPage = new LoginPage(GetDriver())
                .Login("standard_user", "secret_sauce")
                .AddFirstItemToCart()
                .GoToCart()
                .GoToCheckout();

            checkoutPage.FillShippingInfo(
                data["firstName"], data["lastName"], data["postalCode"]);
            checkoutPage.FinishOrder();

            Assert.That(checkoutPage.IsOrderComplete(), Is.True,
                "Trang hoàn thành đặt hàng không hiển thị với Faker data");
        }

        [Test]
        [Category("faker")]
        [Description("BÀI 4B: Checkout lần 2 – so sánh log với lần 1 để thấy data khác nhau")]
        [RetryOnFailure]
        public void TestCheckout_WithFakerData_Run2()
        {
            // Sinh dữ liệu LẦN 2 – khác với lần 1 (chứng minh tính ngẫu nhiên)
            var data = TestDataFactory.RandomCheckoutData();

            Console.WriteLine("╔══════════════════════════════════════════╗");
            Console.WriteLine("║  BÀI 4B – RUN 2: Faker Data              ║");
            Console.WriteLine($"║  Tên: {data["firstName"]} {data["lastName"],-20} ║");
            Console.WriteLine($"║  ZIP: {data["postalCode"],-35} ║");
            Console.WriteLine("╚══════════════════════════════════════════╝");

            var checkoutPage = new LoginPage(GetDriver())
                .Login("standard_user", "secret_sauce")
                .AddFirstItemToCart()
                .GoToCart()
                .GoToCheckout();

            checkoutPage.FillShippingInfo(
                data["firstName"], data["lastName"], data["postalCode"]);
            checkoutPage.FinishOrder();

            Assert.That(checkoutPage.IsOrderComplete(), Is.True,
                "Trang hoàn thành đặt hàng không hiển thị với Faker data lần 2");
        }

        [Test]
        [Category("faker")]
        [Description("BÀI 4B: Chứng minh Faker sinh email, phone, address ngẫu nhiên")]
        public void TestFakerDataVariety()
        {
            // Không cần chạy browser – chỉ chứng minh data generation
            Console.WriteLine("═══════════ FAKER DATA SAMPLES ═══════════");
            for (int i = 1; i <= 5; i++)
            {
                Console.WriteLine($"Sample {i}:");
                Console.WriteLine($"  Name:    {TestDataFactory.RandomFullName()}");
                Console.WriteLine($"  Email:   {TestDataFactory.RandomEmail()}");
                Console.WriteLine($"  Phone:   {TestDataFactory.RandomPhone()}");
                Console.WriteLine($"  Address: {TestDataFactory.RandomStreet()}, {TestDataFactory.RandomCity()}");
                Console.WriteLine($"  ZIP:     {TestDataFactory.RandomPostalCode()}");
            }
            Console.WriteLine("═══════════════════════════════════════════");

            // Assert đơn giản: tên không rỗng
            Assert.That(TestDataFactory.RandomFirstName(), Is.Not.Empty,
                "Faker FirstName không được rỗng");
            Assert.That(TestDataFactory.RandomPostalCode(), Is.Not.Empty,
                "Faker PostalCode không được rỗng");
        }
    }
}
