using NUnit.Framework;
using SeleniumFramework.Framework.Base;
using SeleniumFramework.Framework.Pages;

namespace SeleniumFramework.Tests
{
    /// <summary>
    /// BÀI 2: Kiểm thử giỏ hàng và checkout saucedemo.com.
    /// Dùng Fluent Interface: Login → AddItem → GoToCart → Checkout.
    /// </summary>
    [TestFixture]
    [Category("cart")]
    public class CartTest : BaseTest
    {
        // Setup common: đăng nhập trước mỗi test có liên quan đến cart
        private InventoryPage LoginAsStandardUser()
        {
            return new LoginPage(GetDriver())
                .Login("standard_user", "secret_sauce");
        }

        [Test]
        [Category("smoke")]
        [Description("TC01: Thêm sản phẩm đầu tiên vào giỏ hàng")]
        public void TestAddFirstItemToCart()
        {
            var inventoryPage = LoginAsStandardUser();
            inventoryPage.AddFirstItemToCart();

            Assert.That(inventoryPage.GetCartItemCount(), Is.EqualTo(1),
                "Badge giỏ hàng phải hiển thị 1 sau khi add 1 item");
        }

        [Test]
        [Category("smoke")]
        [Description("TC02: Xem giỏ hàng sau khi thêm sản phẩm")]
        public void TestViewCart_AfterAddItem()
        {
            var cartPage = LoginAsStandardUser()
                .AddFirstItemToCart()
                .GoToCart();

            Assert.That(cartPage.GetItemCount(), Is.EqualTo(1),
                "Giỏ hàng phải có 1 item");
            Assert.That(cartPage.IsEmpty(), Is.False,
                "Giỏ hàng không được rỗng");
        }

        [Test]
        [Category("smoke")]
        [Description("TC03: Giỏ hàng rỗng khi chưa thêm sản phẩm")]
        public void TestCart_EmptyByDefault()
        {
            var cartPage = LoginAsStandardUser().GoToCart();

            Assert.That(cartPage.GetItemCount(), Is.EqualTo(0),
                "Giỏ hàng phải rỗng khi chưa thêm sản phẩm");
            Assert.That(cartPage.IsEmpty(), Is.True,
                "IsEmpty() phải trả về true khi giỏ rỗng");
        }

        [Test]
        [Category("regression")]
        [Description("TC04: Xóa sản phẩm khỏi giỏ hàng")]
        public void TestRemoveItemFromCart()
        {
            var cartPage = LoginAsStandardUser()
                .AddFirstItemToCart()
                .GoToCart();

            Assert.That(cartPage.GetItemCount(), Is.EqualTo(1),
                "Giỏ phải có 1 item trước khi xóa");

            cartPage.RemoveFirstItem();

            Assert.That(cartPage.GetItemCount(), Is.EqualTo(0),
                "Giỏ phải rỗng sau khi xóa item");
        }

        [Test]
        [Category("regression")]
        [Description("TC05: Thêm nhiều sản phẩm vào giỏ và kiểm tra số lượng")]
        public void TestAddMultipleItems()
        {
            var inventoryPage = LoginAsStandardUser();

            // Thêm sản phẩm theo tên
            inventoryPage.AddItemByName("Sauce Labs Backpack");
            inventoryPage.AddItemByName("Sauce Labs Bike Light");

            Assert.That(inventoryPage.GetCartItemCount(), Is.EqualTo(2),
                "Badge phải hiển thị 2 sau khi add 2 items");
        }

        [Test]
        [Category("smoke")]
        [Description("TC06: Checkout hoàn chỉnh từ đầu đến cuối")]
        [RetryOnFailure]
        public void TestFullCheckoutFlow()
        {
            var checkoutPage = LoginAsStandardUser()
                .AddFirstItemToCart()
                .GoToCart()
                .GoToCheckout();

            checkoutPage.FillShippingInfo("John", "Doe", "12345");
            checkoutPage.FinishOrder();

            Assert.That(checkoutPage.IsOrderComplete(), Is.True,
                "Trang hoàn thành đặt hàng không hiển thị");
        }
    }
}
