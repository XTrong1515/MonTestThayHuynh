using NUnit.Framework;
using SeleniumFramework.Framework.Config;

namespace SeleniumFramework.Tests
{
    /// <summary>
    /// BÀI 5: Kiểm chứng ConfigReader hoạt động đúng trên nhiều môi trường.
    ///
    /// Demo:
    ///   dotnet test --filter "Class=ConfigReaderTest"
    ///       → log "Đang dùng môi trường: dev" | explicit.wait = 15
    ///
    ///   ENV=staging dotnet test --filter "Class=ConfigReaderTest"
    ///       → log "Đang dùng môi trường: staging" | explicit.wait = 20
    ///
    /// KHÔNG hardcode URL hay timeout ở bất kỳ đâu ngoài file .properties.
    /// </summary>
    [TestFixture]
    [Category("config")]
    public class ConfigReaderTest
    {
        [SetUp]
        public void ResetConfig()
        {
            // Reset singleton trước mỗi test để đọc lại từ biến môi trường
            ConfigReader.Reset();
        }

        [Test]
        [Description("BÀI 5: ConfigReader đọc đúng môi trường hiện tại")]
        public void TestConfigReader_LoadsCorrectEnvironment()
        {
            var config = ConfigReader.GetInstance();
            var env    = config.GetCurrentEnv();

            Console.WriteLine($"[ConfigTest] Đang dùng môi trường: {env}");
            Console.WriteLine($"[ConfigTest] base.url        = {config.GetBaseUrl()}");
            Console.WriteLine($"[ConfigTest] browser         = {config.GetBrowser()}");
            Console.WriteLine($"[ConfigTest] explicit.wait   = {config.GetExplicitWait()}");
            Console.WriteLine($"[ConfigTest] implicit.wait   = {config.GetImplicitWait()}");
            Console.WriteLine($"[ConfigTest] retry.count     = {config.GetRetryCount()}");
            Console.WriteLine($"[ConfigTest] screenshot.path = {config.GetScreenshotPath()}");

            // Env phải là dev hoặc staging
            Assert.That(env, Is.AnyOf("dev", "staging", "prod"),
                "Môi trường không hợp lệ – chỉ chấp nhận: dev | staging | prod");
        }

        [Test]
        [Description("BÀI 5: Config dev – explicit.wait=15, retry.count=1")]
        public void TestConfigReader_DevValues()
        {
            // Chỉ chạy khi env=dev
            var config = ConfigReader.GetInstance();
            if (config.GetCurrentEnv() != "dev")
            {
                Assert.Ignore("Bỏ qua – test này chỉ dành cho môi trường dev");
                return;
            }

            Assert.That(config.GetExplicitWait(), Is.EqualTo(15),
                "Dev: explicit.wait phải là 15");
            Assert.That(config.GetRetryCount(), Is.EqualTo(1),
                "Dev: retry.count phải là 1");
            Assert.That(config.GetBaseUrl(), Does.Contain("saucedemo"),
                "Dev: base.url phải trỏ đến saucedemo.com");

            Console.WriteLine($"[ConfigTest] ✅ Dev config xác nhận: wait={config.GetExplicitWait()}, retry={config.GetRetryCount()}");
        }

        [Test]
        [Description("BÀI 5: Config staging – explicit.wait=20, retry.count=2")]
        public void TestConfigReader_StagingValues()
        {
            var config = ConfigReader.GetInstance();
            if (config.GetCurrentEnv() != "staging")
            {
                Assert.Ignore("Bỏ qua – test này chỉ dành cho môi trường staging");
                return;
            }

            Assert.That(config.GetExplicitWait(), Is.EqualTo(20),
                "Staging: explicit.wait phải là 20");
            Assert.That(config.GetRetryCount(), Is.EqualTo(2),
                "Staging: retry.count phải là 2");

            Console.WriteLine($"[ConfigTest] ✅ Staging config xác nhận: wait={config.GetExplicitWait()}, retry={config.GetRetryCount()}");
        }

        [Test]
        [Description("BÀI 5: Singleton – nhiều lần gọi GetInstance() trả về cùng một object")]
        public void TestConfigReader_IsSingleton()
        {
            var instance1 = ConfigReader.GetInstance();
            var instance2 = ConfigReader.GetInstance();
            var instance3 = ConfigReader.GetInstance();

            Assert.That(ReferenceEquals(instance1, instance2), Is.True,
                "GetInstance() phải trả về cùng một instance (Singleton)");
            Assert.That(ReferenceEquals(instance2, instance3), Is.True,
                "GetInstance() phải nhất quán qua nhiều lần gọi");

            Console.WriteLine("[ConfigTest] ✅ Singleton pattern xác nhận");
        }

        [Test]
        [Description("BÀI 5: GetProperty với giá trị mặc định khi key không tồn tại")]
        public void TestConfigReader_DefaultValues()
        {
            var config = ConfigReader.GetInstance();

            var nonExistent = config.GetProperty("nonexistent.key", "DEFAULT_VALUE");
            Assert.That(nonExistent, Is.EqualTo("DEFAULT_VALUE"),
                "Phải trả về default khi key không tồn tại");

            Console.WriteLine("[ConfigTest] ✅ Default value hoạt động đúng");
        }
    }
}
