using NUnit.Framework;
using SeleniumFramework.Framework.Base;
using SeleniumFramework.Framework.Pages;
using SeleniumFramework.Framework.Utils;

namespace SeleniumFramework.Tests
{
    /// <summary>
    /// BÀI 3: Data-Driven Testing từ file Excel login_data.xlsx.
    /// Khi thêm dòng mới vào Excel → test tự chạy thêm case đó, không cần sửa code.
    ///
    /// Cách chạy theo group:
    ///   dotnet test --filter "Category=smoke"      → chỉ SmokeCases sheet
    ///   dotnet test --filter "Category=regression" → tất cả 3 sheets
    /// </summary>
    [TestFixture]
    [Category("ddt")]
    public class LoginDDTTest : BaseTest
    {
        // Đường dẫn file Excel – tương thích nhiều thư mục chạy
        private static string ExcelPath =>
            FindFile(Path.Combine("Resources", "testdata", "login_data.xlsx"));

        private static string FindFile(string relativePath)
        {
            var candidates = new[]
            {
                relativePath,
                Path.Combine("..", relativePath),
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, relativePath),
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "..", "..", "..", relativePath),
            };
            return candidates.FirstOrDefault(File.Exists)
                   ?? throw new FileNotFoundException($"Không tìm thấy: {relativePath}");
        }

        // ─────────────────────────────────────────────────────────────
        // DATA SOURCES – trả về tên test rõ ràng từ cột description
        // ─────────────────────────────────────────────────────────────

        /// <summary>Source cho Smoke tests – đọc sheet SmokeCases.</summary>
        public static IEnumerable<TestCaseData> SmokeLoginData()
            => ExcelReader.GetTestCaseData(ExcelPath, "SmokeCases");

        /// <summary>Source cho Negative tests – đọc sheet NegativeCases.</summary>
        public static IEnumerable<TestCaseData> NegativeLoginData()
            => ExcelReader.GetTestCaseData(ExcelPath, "NegativeCases");

        /// <summary>Source cho Regression – đọc cả 3 sheets, gộp lại.</summary>
        public static IEnumerable<TestCaseData> RegressionLoginData()
            => ExcelReader.GetTestCaseData(ExcelPath, "SmokeCases")
               .Concat(ExcelReader.GetTestCaseData(ExcelPath, "NegativeCases"))
               .Concat(ExcelReader.GetTestCaseData(ExcelPath, "BoundaryCases"));

        // ─────────────────────────────────────────────────────────────
        // BÀI 3 – SMOKE TESTS (Happy path từ SmokeCases sheet)
        // ─────────────────────────────────────────────────────────────

        [Test]
        [Category("smoke")]
        [TestCaseSource(nameof(SmokeLoginData))]
        public void TestLogin_Smoke(string username, string password, string expectedUrl)
        {
            Console.WriteLine($"[DDT-Smoke] username={username} | expectedUrl={expectedUrl}");

            var inventoryPage = new LoginPage(GetDriver()).Login(username, password);

            Assert.That(GetDriver().Url, Does.Contain(expectedUrl),
                $"URL sau đăng nhập không chứa '{expectedUrl}'");
            Assert.That(inventoryPage.IsLoaded(), Is.True,
                "Trang inventory chưa load sau đăng nhập thành công");
        }

        // ─────────────────────────────────────────────────────────────
        // BÀI 3 – NEGATIVE TESTS (từ NegativeCases sheet)
        // ─────────────────────────────────────────────────────────────

        [Test]
        [Category("negative")]
        [TestCaseSource(nameof(NegativeLoginData))]
        public void TestLogin_Negative(string username, string password, string expectedError)
        {
            Console.WriteLine($"[DDT-Neg] username='{username}' | expectedError='{expectedError}'");

            var loginPage = new LoginPage(GetDriver())
                .LoginExpectingFailure(username, password);

            Assert.That(loginPage.IsErrorDisplayed(), Is.True,
                $"Không có thông báo lỗi khi đăng nhập với username='{username}'");
            Assert.That(loginPage.GetErrorMessage(), Does.Contain(expectedError),
                $"Nội dung lỗi không khớp. Kỳ vọng chứa: '{expectedError}'");
        }

        // ─────────────────────────────────────────────────────────────
        // BÀI 3 – REGRESSION = tất cả 3 sheets
        // ─────────────────────────────────────────────────────────────

        [Test]
        [Category("regression")]
        [TestCaseSource(nameof(RegressionLoginData))]
        public void TestLogin_Regression(string username, string password, string expected)
        {
            Console.WriteLine($"[DDT-Regression] username='{username}' | expected='{expected}'");

            // Phân loại: URL fragment → đăng nhập thành công; chuỗi dài → expect lỗi
            bool expectingSuccess = expected.StartsWith("inventory",
                StringComparison.OrdinalIgnoreCase);

            if (expectingSuccess)
            {
                var inventoryPage = new LoginPage(GetDriver()).Login(username, password);
                Assert.That(inventoryPage.IsLoaded(), Is.True,
                    $"[{username}] Trang inventory không load dù kỳ vọng success");
            }
            else
            {
                var loginPage = new LoginPage(GetDriver())
                    .LoginExpectingFailure(username, password);

                Assert.That(loginPage.IsErrorDisplayed(), Is.True,
                    $"[{username}] Không có thông báo lỗi dù kỳ vọng failure");
                Assert.That(loginPage.GetErrorMessage(), Does.Contain(expected),
                    $"[{username}] Nội dung lỗi không khớp");
            }
        }
    }
}
