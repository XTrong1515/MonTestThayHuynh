namespace SeleniumFramework.Framework.Config
{
    /// <summary>
    /// Đọc cấu hình theo môi trường (dev/staging/prod).
    /// Dùng Singleton Pattern để đảm bảo chỉ load file một lần duy nhất.
    /// Chạy với môi trường khác: dotnet test -- NUnit.env=staging
    /// hoặc đặt biến môi trường ENV=staging trước khi chạy.
    /// </summary>
    public sealed class ConfigReader
    {
        private static ConfigReader? _instance;
        private static readonly object Lock = new();
        private readonly Dictionary<string, string> _properties = new();
        private readonly string _currentEnv;

        private ConfigReader()
        {
            // Đọc env từ biến môi trường hệ thống hoặc mặc định "dev"
            _currentEnv = Environment.GetEnvironmentVariable("ENV")
                          ?? Environment.GetEnvironmentVariable("env")
                          ?? "dev";

            // Thử nhiều đường dẫn để tương thích khi chạy từ nhiều thư mục
            var possiblePaths = new[]
            {
                Path.Combine("Resources", "config", $"config-{_currentEnv}.properties"),
                Path.Combine("..", "Resources", "config", $"config-{_currentEnv}.properties"),
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory,
                    "Resources", "config", $"config-{_currentEnv}.properties"),
            };

            string? filePath = possiblePaths.FirstOrDefault(File.Exists);

            if (filePath == null)
            {
                Console.WriteLine($"[ConfigReader] CẢNH BÁO: Không tìm thấy config cho môi trường '{_currentEnv}'. Dùng giá trị mặc định.");
                LoadDefaults();
                return;
            }

            LoadFile(filePath);
            Console.WriteLine($"[ConfigReader] Đang dùng môi trường: {_currentEnv} | File: {filePath}");
        }

        // ─────────────────────────────────────────────────────────────
        // SINGLETON ACCESS
        // ─────────────────────────────────────────────────────────────

        public static ConfigReader GetInstance()
        {
            if (_instance != null) return _instance;
            lock (Lock)
            {
                _instance ??= new ConfigReader();
            }
            return _instance;
        }

        /// <summary>Reset singleton – dùng trong test để reload config với env khác.</summary>
        public static void Reset() { lock (Lock) { _instance = null; } }

        // ─────────────────────────────────────────────────────────────
        // PROPERTY ACCESSORS
        // ─────────────────────────────────────────────────────────────

        public string GetBaseUrl()        => GetProperty("base.url", "https://www.saucedemo.com");
        public string GetBrowser()        => GetProperty("browser", "chrome");
        public int    GetExplicitWait()   => int.Parse(GetProperty("explicit.wait", "15"));
        public int    GetImplicitWait()   => int.Parse(GetProperty("implicit.wait", "5"));
        public int    GetRetryCount()     => int.Parse(GetProperty("retry.count", "1"));
        public string GetScreenshotPath() => GetProperty("screenshot.path", "target/screenshots/");
        public string GetCurrentEnv()     => _currentEnv;

        public string GetProperty(string key, string defaultValue = "")
        {
            return _properties.TryGetValue(key.Trim(), out var value) ? value : defaultValue;
        }

        // ─────────────────────────────────────────────────────────────
        // PRIVATE HELPERS
        // ─────────────────────────────────────────────────────────────

        private void LoadFile(string filePath)
        {
            foreach (var line in File.ReadAllLines(filePath))
            {
                var trimmed = line.Trim();
                // Bỏ qua dòng comment và dòng rỗng
                if (string.IsNullOrWhiteSpace(trimmed) || trimmed.StartsWith('#'))
                    continue;

                var idx = trimmed.IndexOf('=');
                if (idx <= 0) continue;

                var key   = trimmed[..idx].Trim();
                var value = trimmed[(idx + 1)..].Trim();
                _properties[key] = value;
            }
        }

        private void LoadDefaults()
        {
            _properties["base.url"]        = "https://www.saucedemo.com";
            _properties["browser"]         = "chrome";
            _properties["explicit.wait"]   = "15";
            _properties["implicit.wait"]   = "5";
            _properties["screenshot.path"] = "target/screenshots/";
            _properties["retry.count"]     = "1";
        }
    }
}
