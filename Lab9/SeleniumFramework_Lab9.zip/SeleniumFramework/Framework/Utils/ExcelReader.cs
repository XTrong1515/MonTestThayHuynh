using OfficeOpenXml;

namespace SeleniumFramework.Framework.Utils
{
    /// <summary>
    /// Đọc dữ liệu test từ file Excel (.xlsx) dùng thư viện EPPlus.
    /// Dòng đầu tiên (row 1) được coi là header – bị bỏ qua khi đọc data.
    /// Trả về object[][] để tương thích với NUnit TestCaseSource / TestCaseData.
    /// </summary>
    public static class ExcelReader
    {
        static ExcelReader()
        {
            // EPPlus yêu cầu license context cho dự án phi thương mại
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
        }

        /// <summary>
        /// Đọc toàn bộ data từ một sheet Excel (bỏ qua dòng header).
        /// </summary>
        /// <param name="filePath">Đường dẫn tới file .xlsx</param>
        /// <param name="sheetName">Tên sheet cần đọc</param>
        /// <returns>Mảng 2 chiều object[][] chứa data từ dòng 2 trở đi</returns>
        public static object[][] GetData(string filePath, string sheetName)
        {
            if (!File.Exists(filePath))
                throw new FileNotFoundException($"Không tìm thấy file Excel: {filePath}");

            using var package = new ExcelPackage(new FileInfo(filePath));
            var sheet = package.Workbook.Worksheets[sheetName]
                        ?? throw new ArgumentException($"Không tìm thấy sheet: '{sheetName}' trong file {filePath}");

            var lastRow = sheet.Dimension?.End.Row ?? 0;
            var lastCol = sheet.Dimension?.End.Column ?? 0;

            if (lastRow <= 1)
                return Array.Empty<object[]>(); // Chỉ có header, không có data

            var dataRows = new List<object[]>();

            for (int r = 2; r <= lastRow; r++) // Bắt đầu từ dòng 2 (bỏ header)
            {
                // Bỏ qua dòng hoàn toàn rỗng
                bool isEmptyRow = true;
                for (int c = 1; c <= lastCol; c++)
                {
                    if (sheet.Cells[r, c].Value != null)
                    {
                        isEmptyRow = false;
                        break;
                    }
                }
                if (isEmptyRow) continue;

                var row = new object[lastCol];
                for (int c = 1; c <= lastCol; c++)
                    row[c - 1] = GetCellValue(sheet.Cells[r, c]);

                dataRows.Add(row);
            }

            return dataRows.ToArray();
        }

        /// <summary>
        /// Đọc data từ nhiều sheet cùng lúc và gộp lại.
        /// Dùng khi chạy regression test cần dữ liệu từ tất cả sheet.
        /// </summary>
        public static object[][] GetDataFromMultipleSheets(string filePath, params string[] sheetNames)
        {
            var allData = new List<object[]>();
            foreach (var sheetName in sheetNames)
                allData.AddRange(GetData(filePath, sheetName));
            return allData.ToArray();
        }

        /// <summary>
        /// Đọc data và trả về dưới dạng IEnumerable TestCaseData với tên test rõ ràng.
        /// Cột cuối cùng được dùng làm description (tên hiển thị trong TestNG report).
        /// </summary>
        public static IEnumerable<NUnit.Framework.TestCaseData> GetTestCaseData(
            string filePath, string sheetName)
        {
            var data = GetData(filePath, sheetName);
            foreach (var row in data)
            {
                // Cột cuối = description, dùng làm tên test case
                var testName = row.LastOrDefault()?.ToString() ?? "TestCase";
                var args     = row.Take(row.Length - 1).ToArray();
                yield return new NUnit.Framework.TestCaseData(args).SetName(testName);
            }
        }

        // ─────────────────────────────────────────────────────────────
        // PRIVATE HELPER
        // ─────────────────────────────────────────────────────────────

        /// <summary>
        /// Lấy giá trị từ cell, xử lý null và các kiểu dữ liệu khác nhau.
        /// Cell null → trả về chuỗi rỗng, không throw NullPointerException.
        /// </summary>
        private static string GetCellValue(ExcelRange cell)
        {
            if (cell?.Value == null) return string.Empty;

            return cell.Value switch
            {
                string s   => s.Trim(),
                double d   => ((long)d).ToString(),    // Excel lưu số nguyên dưới dạng double
                bool b     => b.ToString().ToLower(),
                DateTime dt => dt.ToString("yyyy-MM-dd"),
                _ => cell.Value.ToString()?.Trim() ?? string.Empty
            };
        }
    }
}
