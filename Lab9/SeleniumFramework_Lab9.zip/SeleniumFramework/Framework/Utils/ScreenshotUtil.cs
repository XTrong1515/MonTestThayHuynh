using OpenQA.Selenium;

namespace SeleniumFramework.Framework.Utils
{
    /// <summary>
    /// Tiện ích chụp ảnh màn hình khi test fail.
    /// Lưu vào thư mục target/screenshots/ với tên = {testName}_{timestamp}.png
    /// </summary>
    public static class ScreenshotUtil
    {
        /// <summary>Chụp ảnh và lưu file. Trả về đường dẫn file đã lưu.</summary>
        public static string Capture(IWebDriver driver, string testName)
        {
            try
            {
                var screenshotDir = ConfigReader.GetInstance().GetScreenshotPath();
                Directory.CreateDirectory(screenshotDir);

                var timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss_fff");
                var safeName  = string.Concat(testName.Split(Path.GetInvalidFileNameChars()));
                var fileName  = $"{safeName}_{timestamp}.png";
                var fullPath  = Path.Combine(screenshotDir, fileName);

                var screenshot = ((ITakesScreenshot)driver).GetScreenshot();
                screenshot.SaveAsFile(fullPath);

                Console.WriteLine($"[Screenshot] Đã lưu: {fullPath}");
                return fullPath;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Screenshot] Lỗi chụp ảnh: {ex.Message}");
                return string.Empty;
            }
        }

        /// <summary>Chụp ảnh và trả về mảng byte (dùng đính kèm vào report).</summary>
        public static byte[] CaptureAsBytes(IWebDriver driver)
        {
            try
            {
                return ((ITakesScreenshot)driver).GetScreenshot().AsByteArray;
            }
            catch
            {
                return Array.Empty<byte>();
            }
        }
    }
}
