using Newtonsoft.Json;

namespace SeleniumFramework.Framework.Utils
{
    // ─────────────────────────────────────────────────────────────────────
    // DATA MODEL (POJO equivalent in C#)
    // ─────────────────────────────────────────────────────────────────────

    /// <summary>
    /// POCO mapping cho file users.json.
    /// Dùng JsonProperty để ánh xạ chính xác tên field JSON sang C# property.
    /// </summary>
    public class UserData
    {
        [JsonProperty("username")]
        public string Username { get; set; } = string.Empty;

        [JsonProperty("password")]
        public string Password { get; set; } = string.Empty;

        [JsonProperty("role")]
        public string Role { get; set; } = string.Empty;

        [JsonProperty("expectSuccess")]
        public bool ExpectSuccess { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; } = string.Empty;
    }

    // ─────────────────────────────────────────────────────────────────────
    // JSON READER
    // ─────────────────────────────────────────────────────────────────────

    /// <summary>
    /// Đọc dữ liệu test từ file JSON dùng Newtonsoft.Json.
    /// Dùng cho dữ liệu có cấu trúc phức tạp (nested objects, arrays).
    /// </summary>
    public static class JsonReader
    {
        /// <summary>
        /// Đọc danh sách UserData từ file JSON.
        /// </summary>
        public static List<UserData> ReadUsers(string filePath)
        {
            if (!File.Exists(filePath))
                throw new FileNotFoundException($"Không tìm thấy file JSON: {filePath}");

            var json = File.ReadAllText(filePath);
            return JsonConvert.DeserializeObject<List<UserData>>(json)
                   ?? new List<UserData>();
        }

        /// <summary>
        /// Đọc danh sách generic từ JSON file.
        /// </summary>
        public static List<T> ReadList<T>(string filePath)
        {
            if (!File.Exists(filePath))
                throw new FileNotFoundException($"Không tìm thấy file JSON: {filePath}");

            var json = File.ReadAllText(filePath);
            return JsonConvert.DeserializeObject<List<T>>(json) ?? new List<T>();
        }

        /// <summary>
        /// Đọc users và trả về IEnumerable TestCaseData cho NUnit DataSource.
        /// </summary>
        public static IEnumerable<NUnit.Framework.TestCaseData> GetUserTestCases(string filePath)
        {
            var users = ReadUsers(filePath);
            foreach (var u in users)
            {
                yield return new NUnit.Framework.TestCaseData(
                    u.Username, u.Password, u.ExpectSuccess)
                    .SetName(u.Description);
            }
        }
    }
}
