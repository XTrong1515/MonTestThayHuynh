using NUnit.Framework;
using NUnit.Framework.Interfaces;
using NUnit.Framework.Internal;
using NUnit.Framework.Internal.Commands;

namespace SeleniumFramework.Framework.Utils
{
    /// <summary>
    /// Attribute tự động chạy lại test bị fail (flaky test retry).
    /// Dùng khi test fail do lỗi mạng tạm thời, server lag, hoặc race condition DOM.
    /// Cách dùng: [RetryOnFailure] hoặc [RetryOnFailure(3)]
    /// Số lần retry đọc từ ConfigReader nếu không truyền tham số.
    /// </summary>
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false, Inherited = false)]
    public class RetryOnFailureAttribute : NUnitAttribute, IRepeatTest
    {
        private readonly int _tryCount;

        /// <summary>Dùng số lần retry từ config-{env}.properties (retry.count).</summary>
        public RetryOnFailureAttribute()
        {
            var fromConfig = ConfigReader.GetInstance().GetRetryCount();
            // tryCount = 1 lần thử gốc + số lần retry
            _tryCount = fromConfig + 1;
        }

        /// <summary>Chỉ định số lần retry cụ thể, bỏ qua config.</summary>
        public RetryOnFailureAttribute(int retryCount)
        {
            _tryCount = retryCount + 1;
        }

        public TestCommand Wrap(TestCommand command)
        {
            return new RetryCommand(command, _tryCount);
        }
    }

    /// <summary>
    /// NUnit TestCommand thực thi logic retry.
    /// </summary>
    internal class RetryCommand : DelegatingTestCommand
    {
        private readonly int _tryCount;

        public RetryCommand(TestCommand innerCommand, int tryCount)
            : base(innerCommand)
        {
            _tryCount = tryCount;
        }

        public override TestResult Execute(TestExecutionContext context)
        {
            var count = _tryCount;
            while (count-- > 0)
            {
                try
                {
                    context.CurrentResult = innerCommand.Execute(context);
                }
                catch (Exception ex)
                {
                    context.CurrentResult ??= context.CurrentTest.MakeTestResult();
                    context.CurrentResult.RecordException(ex);
                }

                if (context.CurrentResult.ResultState != ResultState.Failure
                    && context.CurrentResult.ResultState != ResultState.Error)
                {
                    break;
                }

                if (count > 0)
                {
                    var attempt = _tryCount - count;
                    Console.WriteLine(
                        $"[Retry] Lần {attempt}/{_tryCount - 1}: {context.CurrentTest.FullName}");

                    // Reset context để thử lại
                    context.CurrentResult = context.CurrentTest.MakeTestResult();
                }
            }

            return context.CurrentResult;
        }
    }
}
