using Bogus;

namespace SeleniumFramework.Framework.Utils
{
    /// <summary>
    /// Factory tập trung logic sinh dữ liệu test ngẫu nhiên dùng thư viện Bogus.
    /// Bogus là tương đương C# của Java Faker – sinh họ tên, email, địa chỉ giả thực tế.
    ///
    /// BÀI 4B: Mỗi lần chạy test sinh dữ liệu khác nhau.
    /// Tập trung tất cả logic sinh data ở đây – KHÔNG scatter khắp test class.
    /// </summary>
    public static class TestDataFactory
    {
        // Bogus Faker với locale tiếng Anh (dữ liệu chuẩn quốc tế)
        private static readonly Faker Faker = new Faker("en");

        // ─────────────────────────────────────────────────────────────
        // THÔNG TIN CÁ NHÂN
        // ─────────────────────────────────────────────────────────────

        public static string RandomFirstName()  => Faker.Name.FirstName();
        public static string RandomLastName()   => Faker.Name.LastName();
        public static string RandomFullName()   => Faker.Name.FullName();
        public static string RandomEmail()      => Faker.Internet.Email();
        public static string RandomPhone()      => Faker.Phone.PhoneNumber("###-###-####");
        public static string RandomPostalCode() => Faker.Address.ZipCode();
        public static string RandomCity()       => Faker.Address.City();
        public static string RandomState()      => Faker.Address.State();
        public static string RandomStreet()     => Faker.Address.StreetAddress();

        // ─────────────────────────────────────────────────────────────
        // DỮ LIỆU CHECKOUT HOÀN CHỈNH
        // ─────────────────────────────────────────────────────────────

        /// <summary>
        /// Sinh bộ dữ liệu checkout đầy đủ.
        /// Mỗi lần gọi trả về dữ liệu khác nhau – chứng minh bằng log khi chạy 2 lần.
        /// </summary>
        public static Dictionary<string, string> RandomCheckoutData()
        {
            var data = new Dictionary<string, string>
            {
                ["firstName"]  = RandomFirstName(),
                ["lastName"]   = RandomLastName(),
                ["postalCode"] = RandomPostalCode(),
                ["city"]       = RandomCity(),
                ["street"]     = RandomStreet()
            };

            Console.WriteLine($"[TestDataFactory] Checkout data sinh ra: " +
                $"{data["firstName"]} {data["lastName"]}, ZIP: {data["postalCode"]}");
            return data;
        }

        // ─────────────────────────────────────────────────────────────
        // DỮ LIỆU BIÊN (BOUNDARY DATA)
        // ─────────────────────────────────────────────────────────────

        /// <summary>Sinh chuỗi dài để test boundary – mặc định 256 ký tự.</summary>
        public static string LongString(int length = 256)
            => Faker.Random.String2(length);

        /// <summary>Sinh chuỗi ký tự đặc biệt để test injection/XSS.</summary>
        public static string SpecialCharsString()
            => Faker.PickRandom(
                "<script>alert(1)</script>",
                "'; DROP TABLE users; --",
                "!@#$%^&*()",
                "   ",
                "\n\t\r",
                "áéíóú çñ ü");

        /// <summary>Sinh số ngẫu nhiên dạng chuỗi.</summary>
        public static string RandomNumericString(int digits = 5)
            => Faker.Random.Number(10000, 99999).ToString();

        // ─────────────────────────────────────────────────────────────
        // DỮ LIỆU ĐĂNG NHẬP
        // ─────────────────────────────────────────────────────────────

        /// <summary>Sinh username ngẫu nhiên (không tồn tại) để test error case.</summary>
        public static string RandomInvalidUsername()
            => $"user_{Faker.Random.AlphaNumeric(8)}";

        /// <summary>Sinh password ngẫu nhiên để test error case.</summary>
        public static string RandomInvalidPassword()
            => Faker.Internet.Password(12);

        // ─────────────────────────────────────────────────────────────
        // SEED (Reproducible data cho debugging)
        // ─────────────────────────────────────────────────────────────

        /// <summary>
        /// Tạo Faker với seed cố định – sinh dữ liệu reproducible khi debug.
        /// Dùng: var data = TestDataFactory.CreateSeededFaker(42).Name.FirstName();
        /// </summary>
        public static Faker CreateSeededFaker(int seed) => new Faker("en").UseSeed(seed);
    }
}
