using OpenQA.Selenium;
using SeleniumFramework.Framework.Base;

namespace SeleniumFramework.Framework.Pages
{
    /// <summary>
    /// Page Object cho trang danh sách sản phẩm saucedemo.com (/inventory.html).
    /// </summary>
    public class InventoryPage : BasePage
    {
        // ─────────────────────────────────────────────────────────────
        // LOCATORS
        // ─────────────────────────────────────────────────────────────
        private readonly By _inventoryList      = By.CssSelector(".inventory_list");
        private readonly By _cartBadge          = By.CssSelector(".shopping_cart_badge");
        private readonly By _cartLink           = By.CssSelector(".shopping_cart_link");
        private readonly By _addToCartButtons   = By.CssSelector(".inventory_item button");
        private readonly By _inventoryItems     = By.CssSelector(".inventory_item");
        private readonly By _productNames       = By.CssSelector(".inventory_item_name");

        public InventoryPage(IWebDriver driver) : base(driver) { }

        // ─────────────────────────────────────────────────────────────
        // ACTION METHODS
        // ─────────────────────────────────────────────────────────────

        /// <summary>Kiểm tra trang inventory đã load thành công.</summary>
        public bool IsLoaded()
        {
            WaitForPageLoad();
            return IsElementVisible(_inventoryList);
        }

        /// <summary>Thêm sản phẩm đầu tiên vào giỏ hàng. Trả về InventoryPage (Fluent Interface).</summary>
        public InventoryPage AddFirstItemToCart()
        {
            var buttons = Driver.FindElements(_addToCartButtons);
            if (buttons.Count > 0)
                WaitAndClick(buttons[0]);
            return this;
        }

        /// <summary>
        /// Thêm sản phẩm vào giỏ theo tên hiển thị.
        /// Tìm item có tên khớp rồi click nút Add to Cart tương ứng.
        /// </summary>
        public InventoryPage AddItemByName(string productName)
        {
            var items = Driver.FindElements(_inventoryItems);
            foreach (var item in items)
            {
                var nameEl = item.FindElement(By.CssSelector(".inventory_item_name"));
                if (nameEl.Text.Trim().Equals(productName, StringComparison.OrdinalIgnoreCase))
                {
                    var btn = item.FindElement(By.CssSelector("button"));
                    WaitAndClick(btn);
                    return this;
                }
            }
            throw new Exception($"Không tìm thấy sản phẩm: '{productName}'");
        }

        /// <summary>
        /// Lấy số lượng item hiện có trong giỏ hàng (từ badge).
        /// Trả về 0 nếu giỏ rỗng (badge không hiển thị).
        /// </summary>
        public int GetCartItemCount()
        {
            try
            {
                var badge = Driver.FindElement(_cartBadge);
                return int.TryParse(badge.Text.Trim(), out var count) ? count : 0;
            }
            catch (NoSuchElementException)
            {
                return 0; // Giỏ rỗng, badge không hiện
            }
        }

        /// <summary>Điều hướng đến trang giỏ hàng. Trả về CartPage.</summary>
        public CartPage GoToCart()
        {
            WaitAndClick(WaitForVisible(_cartLink));
            return new CartPage(Driver);
        }

        /// <summary>Lấy danh sách tên tất cả sản phẩm trên trang.</summary>
        public List<string> GetAllProductNames()
        {
            return Driver.FindElements(_productNames)
                         .Select(el => el.Text.Trim())
                         .ToList();
        }

        /// <summary>Lấy URL hiện tại để xác nhận đang ở đúng trang.</summary>
        public string GetCurrentPageUrl() => GetCurrentUrl();
    }
}
