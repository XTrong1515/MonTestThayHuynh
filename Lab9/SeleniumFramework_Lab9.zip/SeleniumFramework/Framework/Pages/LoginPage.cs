using OpenQA.Selenium;
using SeleniumFramework.Framework.Base;

namespace SeleniumFramework.Framework.Pages
{
    /// <summary>
    /// Page Object cho trang đăng nhập saucedemo.com.
    /// Chứa locator và action method – KHÔNG chứa assertion.
    /// Test class KHÔNG được gọi Driver.FindElement() trực tiếp.
    /// </summary>
    public class LoginPage : BasePage
    {
        // ─────────────────────────────────────────────────────────────
        // LOCATORS – định nghĩa một lần duy nhất
        // ─────────────────────────────────────────────────────────────
        private readonly By _usernameField   = By.Id("user-name");
        private readonly By _passwordField   = By.Id("password");
        private readonly By _loginButton     = By.Id("login-button");
        private readonly By _errorMessage    = By.CssSelector("[data-test='error']");

        public LoginPage(IWebDriver driver) : base(driver) { }

        // ─────────────────────────────────────────────────────────────
        // ACTION METHODS
        // ─────────────────────────────────────────────────────────────

        /// <summary>
        /// Đăng nhập với user hợp lệ – trả về InventoryPage (Fluent Interface).
        /// Dùng khi test case kỳ vọng đăng nhập thành công.
        /// </summary>
        public InventoryPage Login(string username, string password)
        {
            WaitAndType(WaitForVisible(_usernameField), username);
            WaitAndType(WaitForVisible(_passwordField), password);
            WaitAndClick(WaitForVisible(_loginButton));
            return new InventoryPage(Driver);
        }

        /// <summary>
        /// Đăng nhập biết trước sẽ thất bại – trả về chính LoginPage.
        /// Dùng khi test case kỳ vọng thông báo lỗi xuất hiện.
        /// </summary>
        public LoginPage LoginExpectingFailure(string username, string password)
        {
            WaitAndType(WaitForVisible(_usernameField), username);
            WaitAndType(WaitForVisible(_passwordField), password);
            WaitAndClick(WaitForVisible(_loginButton));
            return this;
        }

        /// <summary>Lấy nội dung thông báo lỗi sau khi đăng nhập thất bại.</summary>
        public string GetErrorMessage()
        {
            return GetText(WaitForVisible(_errorMessage));
        }

        /// <summary>Kiểm tra thông báo lỗi có hiển thị không.</summary>
        public bool IsErrorDisplayed()
        {
            return IsElementVisible(_errorMessage);
        }

        /// <summary>Kiểm tra trang login đã load (login button hiển thị).</summary>
        public bool IsLoaded()
        {
            return IsElementVisible(_loginButton);
        }
    }
}
