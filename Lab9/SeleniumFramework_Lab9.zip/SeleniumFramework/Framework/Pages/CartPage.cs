using OpenQA.Selenium;
using SeleniumFramework.Framework.Base;

namespace SeleniumFramework.Framework.Pages
{
    /// <summary>
    /// Page Object cho trang giỏ hàng saucedemo.com (/cart.html).
    /// </summary>
    public class CartPage : BasePage
    {
        // ─────────────────────────────────────────────────────────────
        // LOCATORS
        // ─────────────────────────────────────────────────────────────
        private readonly By _cartItems       = By.CssSelector(".cart_item");
        private readonly By _itemNames       = By.CssSelector(".inventory_item_name");
        private readonly By _removeButtons   = By.CssSelector(".cart_item .btn_secondary, .cart_item [data-test^='remove']");
        private readonly By _checkoutButton  = By.Id("checkout");
        private readonly By _continueButton  = By.Id("continue-shopping");

        public CartPage(IWebDriver driver) : base(driver) { }

        // ─────────────────────────────────────────────────────────────
        // ACTION METHODS
        // ─────────────────────────────────────────────────────────────

        /// <summary>
        /// Đếm số lượng item trong giỏ hàng.
        /// Trả về 0 nếu giỏ rỗng – không throw exception.
        /// </summary>
        public int GetItemCount()
        {
            try
            {
                return Driver.FindElements(_cartItems).Count;
            }
            catch
            {
                return 0;
            }
        }

        /// <summary>Xóa item đầu tiên khỏi giỏ. Trả về CartPage (Fluent Interface).</summary>
        public CartPage RemoveFirstItem()
        {
            var removeButtons = Driver.FindElements(_removeButtons);
            if (removeButtons.Count > 0)
                WaitAndClick(removeButtons[0]);
            return this;
        }

        /// <summary>Lấy danh sách tên các sản phẩm trong giỏ hàng.</summary>
        public List<string> GetItemNames()
        {
            return Driver.FindElements(_itemNames)
                         .Select(el => el.Text.Trim())
                         .ToList();
        }

        /// <summary>Điều hướng đến trang checkout. Trả về CheckoutPage.</summary>
        public CheckoutPage GoToCheckout()
        {
            WaitAndClick(WaitForVisible(_checkoutButton));
            return new CheckoutPage(Driver);
        }

        /// <summary>Tiếp tục mua sắm – quay về InventoryPage.</summary>
        public InventoryPage ContinueShopping()
        {
            WaitAndClick(WaitForVisible(_continueButton));
            return new InventoryPage(Driver);
        }

        /// <summary>Kiểm tra giỏ hàng có rỗng không.</summary>
        public bool IsEmpty() => GetItemCount() == 0;
    }

    /// <summary>
    /// Page Object cho trang checkout saucedemo.com (/checkout-step-one.html).
    /// </summary>
    public class CheckoutPage : BasePage
    {
        private readonly By _firstNameField  = By.Id("first-name");
        private readonly By _lastNameField   = By.Id("last-name");
        private readonly By _postalCodeField = By.Id("postal-code");
        private readonly By _continueButton  = By.Id("continue");
        private readonly By _cancelButton    = By.Id("cancel");
        private readonly By _errorMessage    = By.CssSelector("[data-test='error']");
        private readonly By _finishButton    = By.Id("finish");
        private readonly By _completeHeader  = By.CssSelector(".complete-header");

        public CheckoutPage(IWebDriver driver) : base(driver) { }

        /// <summary>Điền thông tin checkout và tiếp tục.</summary>
        public CheckoutPage FillShippingInfo(string firstName, string lastName, string postalCode)
        {
            WaitAndType(WaitForVisible(_firstNameField), firstName);
            WaitAndType(WaitForVisible(_lastNameField), lastName);
            WaitAndType(WaitForVisible(_postalCodeField), postalCode);
            WaitAndClick(WaitForVisible(_continueButton));
            return this;
        }

        /// <summary>Hoàn tất đặt hàng.</summary>
        public CheckoutPage FinishOrder()
        {
            WaitAndClick(WaitForVisible(_finishButton));
            return this;
        }

        /// <summary>Kiểm tra đặt hàng thành công.</summary>
        public bool IsOrderComplete()
        {
            return IsElementVisible(_completeHeader);
        }

        /// <summary>Lấy thông báo lỗi nếu có.</summary>
        public string GetErrorMessage()
        {
            return IsElementVisible(_errorMessage)
                ? GetText(Driver.FindElement(_errorMessage))
                : string.Empty;
        }

        /// <summary>Lấy text của complete header.</summary>
        public string GetCompleteHeaderText()
        {
            return IsElementVisible(_completeHeader)
                ? GetText(Driver.FindElement(_completeHeader))
                : string.Empty;
        }
    }
}
