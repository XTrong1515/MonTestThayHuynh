using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;

namespace SeleniumFramework.Framework.Base
{
    /// <summary>
    /// Lớp nền tảng cho mọi Page Object.
    /// Đóng gói tất cả thao tác WebDriver phổ biến với Explicit Wait tích hợp sẵn.
    /// Mọi Page Object đều kế thừa BasePage để tái sử dụng các method này.
    ///
    /// KHÔNG dùng Thread.Sleep() – luôn dùng Explicit Wait.
    /// Nguyên tắc: Page Object chứa locator + action, KHÔNG chứa Assert.
    /// </summary>
    public abstract class BasePage
    {
        protected readonly IWebDriver Driver;
        protected readonly WebDriverWait Wait;

        protected BasePage(IWebDriver driver)
        {
            Driver = driver;
            var waitSeconds = Config.ConfigReader.GetInstance().GetExplicitWait();
            Wait = new WebDriverWait(driver, TimeSpan.FromSeconds(waitSeconds));
        }

        // 7 METHOD BẮT BUỘC (không dùng Thread.Sleep)

        /// <summary>Chờ element có thể click rồi mới click. Tránh ElementNotInteractableException.</summary>
        protected void WaitAndClick(IWebElement element)
        {
            Wait.Until(ExpectedConditions.ElementToBeClickable(element)).Click();
        }

        /// <summary>Chờ element clickable, xóa nội dung cũ rồi gõ text. Tránh append vào data cũ.</summary>
        protected void WaitAndType(IWebElement element, string text)
        {
            Wait.Until(ExpectedConditions.ElementToBeClickable(element));
            element.Clear();
            element.SendKeys(text);
        }

        /// <summary>Lấy text của element đã trim whitespace. Chờ element visible trước khi đọc.</summary>
        protected string GetText(IWebElement element)
        {
            Wait.Until(ExpectedConditions.ElementToBeClickable(element));
            return element.Text.Trim();
        }

        /// <summary>
        /// Kiểm tra element có hiển thị không. KHÔNG throw exception.
        /// Xử lý StaleElementReferenceException khi trang re-render DOM.
        /// </summary>
        protected bool IsElementVisible(By locator)
        {
            try
            {
                return Driver.FindElement(locator).Displayed;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
            catch (StaleElementReferenceException)
            {
                try { return Driver.FindElement(locator).Displayed; }
                catch { return false; }
            }
        }

        /// <summary>Cuộn trang đến element bằng JavaScript. Dùng khi element ngoài viewport.</summary>
        protected void ScrollToElement(IWebElement element)
        {
            ((IJavaScriptExecutor)Driver)
                .ExecuteScript("arguments[0].scrollIntoView(true);", element);
        }

        /// <summary>Chờ document.readyState === 'complete'. Gọi sau navigate để DOM sẵn sàng.</summary>
        protected void WaitForPageLoad()
        {
            Wait.Until(driver =>
                ((IJavaScriptExecutor)driver)
                    .ExecuteScript("return document.readyState")?.ToString() == "complete");
        }

        /// <summary>Lấy giá trị attribute HTML. Ví dụ: GetAttribute(field, "value").</summary>
        protected string GetAttribute(IWebElement element, string attributeName)
        {
            Wait.Until(ExpectedConditions.ElementToBeClickable(element));
            return element.GetAttribute(attributeName) ?? string.Empty;
        }

        // HELPER METHODS BỔ SUNG

        protected IWebElement WaitForVisible(By locator)
            => Wait.Until(ExpectedConditions.ElementIsVisible(locator));

        protected void JavaScriptClick(IWebElement element)
            => ((IJavaScriptExecutor)Driver).ExecuteScript("arguments[0].click();", element);

        protected void HoverOver(IWebElement element)
            => new Actions(Driver).MoveToElement(element).Perform();

        protected string GetCurrentUrl() => Driver.Url;
        protected string GetPageTitle()  => Driver.Title;
    }
}
