using NUnit.Framework;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;
using SeleniumFramework.Framework.Config;
using SeleniumFramework.Framework.Utils;

namespace SeleniumFramework.Framework.Base
{
    /// <summary>
    /// Lớp cha cho mọi test class.
    /// Quản lý vòng đời WebDriver: khởi tạo trước mỗi test, dọn dẹp sau mỗi test.
    /// Dùng ThreadLocal để hỗ trợ chạy song song an toàn (parallel test execution).
    /// Mọi test class phải kế thừa BaseTest và dùng GetDriver() – KHÔNG tạo driver mới.
    /// </summary>
    public abstract class BaseTest
    {
        // ThreadLocal đảm bảo mỗi thread có instance WebDriver riêng
        // Tránh race condition khi chạy test song song
        private static readonly ThreadLocal<IWebDriver> TlDriver = new();

        /// <summary>Lấy WebDriver của thread hiện tại.</summary>
        protected static IWebDriver GetDriver() => TlDriver.Value!;

        // ─────────────────────────────────────────────────────────────
        // BÀI 1: SETUP VÀ TEARDOWN
        // ─────────────────────────────────────────────────────────────

        /// <summary>
        /// Khởi tạo WebDriver trước mỗi test method.
        /// Browser và env đọc từ biến môi trường hoặc giá trị mặc định từ config.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            // Đọc browser từ biến môi trường – mặc định chrome
            var browser = Environment.GetEnvironmentVariable("BROWSER")
                          ?? ConfigReader.GetInstance().GetBrowser();

            // Đọc env từ biến môi trường hệ thống – mặc định dev
            // (ConfigReader đã xử lý ở constructor, chỉ log lại ở đây)
            var env = ConfigReader.GetInstance().GetCurrentEnv();

            Console.WriteLine($"[BaseTest] Setup | Browser: {browser} | Env: {env}");

            var driver = DriverFactory.CreateDriver(browser);
            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitWait =
                TimeSpan.FromSeconds(ConfigReader.GetInstance().GetImplicitWait());

            // Điều hướng đến URL của môi trường hiện tại
            driver.Navigate().GoToUrl(ConfigReader.GetInstance().GetBaseUrl());

            TlDriver.Value = driver;
        }

        /// <summary>
        /// Dọn dẹp WebDriver sau mỗi test method.
        /// Chụp ảnh màn hình nếu test FAIL để hỗ trợ debug.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
            var result = TestContext.CurrentContext.Result.Outcome;

            // Chụp ảnh khi test fail hoặc error
            if (result == NUnit.Framework.Interfaces.ResultState.Failure
                || result == NUnit.Framework.Interfaces.ResultState.Error)
            {
                var testName = TestContext.CurrentContext.Test.MethodName
                               ?? TestContext.CurrentContext.Test.Name;

                var screenshotPath = ScreenshotUtil.Capture(GetDriver(), testName);
                Console.WriteLine($"[BaseTest] Test FAIL → screenshot: {screenshotPath}");

                // Đính kèm ảnh vào NUnit report (hiển thị trong test output)
                if (!string.IsNullOrEmpty(screenshotPath) && File.Exists(screenshotPath))
                {
                    TestContext.AddTestAttachment(screenshotPath, "Screenshot khi fail");
                }
            }

            // Quit và giải phóng driver – tránh memory leak
            if (TlDriver.Value != null)
            {
                TlDriver.Value.Quit();
                TlDriver.Value.Dispose();
                TlDriver.Value = null!;
                Console.WriteLine("[BaseTest] Driver đã được đóng và giải phóng.");
            }
        }
    }
}
