using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Edge;
using WebDriverManager;
using WebDriverManager.DriverConfigs.Impl;
using WebDriverManager.Helpers;

namespace SeleniumFramework.Framework.Base
{
    /// <summary>
    /// Factory tạo WebDriver theo tên browser.
    /// Tách logic khởi tạo driver ra khỏi BaseTest để dễ mở rộng thêm browser mới.
    /// </summary>
    public static class DriverFactory
    {
        /// <summary>
        /// Tạo WebDriver tương ứng với tên browser truyền vào.
        /// Tự động tải driver binary phù hợp qua WebDriverManager.
        /// </summary>
        /// <param name="browser">Tên browser: chrome | firefox | edge</param>
        /// <returns>Instance WebDriver đã sẵn sàng dùng</returns>
        public static IWebDriver CreateDriver(string browser)
        {
            return browser.ToLower().Trim() switch
            {
                "chrome" => CreateChromeDriver(),
                "firefox" => CreateFirefoxDriver(),
                "edge" => CreateEdgeDriver(),
                _ => throw new ArgumentException(
                    $"Browser '{browser}' không được hỗ trợ. Dùng: chrome | firefox | edge")
            };
        }

        private static IWebDriver CreateChromeDriver()
        {
            new DriverManager().SetUpDriver(new ChromeConfig(), VersionResolveStrategy.MatchingBrowser);
            var options = new ChromeOptions();
            // Headless mode – bật khi chạy trên CI/CD không có màn hình
            // options.AddArgument("--headless");
            options.AddArgument("--no-sandbox");
            options.AddArgument("--disable-dev-shm-usage");
            options.AddArgument("--disable-gpu");
            options.AddArgument("--window-size=1920,1080");
            return new ChromeDriver(options);
        }

        private static IWebDriver CreateFirefoxDriver()
        {
            new DriverManager().SetUpDriver(new FirefoxConfig(), VersionResolveStrategy.MatchingBrowser);
            var options = new FirefoxOptions();
            return new FirefoxDriver(options);
        }

        private static IWebDriver CreateEdgeDriver()
        {
            new DriverManager().SetUpDriver(new EdgeConfig(), VersionResolveStrategy.MatchingBrowser);
            var options = new EdgeOptions();
            return new EdgeDriver(options);
        }
    }
}
